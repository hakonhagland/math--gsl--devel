
array_wrapper * our_gsl_ran_shuffle(const gsl_rng *r, int *v, size_t n);
array_wrapper * our_gsl_ran_choose(const gsl_rng* r, size_t k, int* v, size_t n);
array_wrapper * our_gsl_ran_sample(const gsl_rng* r, size_t k, int* v, size_t n);
